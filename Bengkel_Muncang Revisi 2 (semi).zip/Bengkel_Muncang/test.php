<?php
require_once 'config.php';

$exclude = array("id", "nameandsurname", "departument", "phone", "computer", "date");
$result = pg_query("SELECT * FROM motor") or   die('error');
$columns = array();
while ($row = pg_fetch_array($result))
{
    if (!in_array($row[0], $exclude)) 
    {
        $columns[] = $row[0];
    }
}

foreach ($columns as $column) {
    echo '<tr><td bgcolor="#ddddff">'.$column.'<br />';
    if (stripos($column, "privileges") !== false) {
        echo '<p><a class="hint" href="#">
                <input type="text" name="'.$column.'">
                <span>Privileges like "occupation" or "like  someone"</span></a>';
    } else {
        echo '<select name="'.$column.'">
                <option value = "No">No
                <option value = "Yes">Yes
              </select>';
    }
    echo '</td></tr>';
}

$keys = array();
$values = array();
foreach ($columns as $column) {
    $value = trim($_POST[$column]);
    $value = pg_real_escape_string($value);
    $keys[] = "`{$column}`";
    $values[] = "'{$value}'";
}
$query = "INSERT INTO 'employees' (" . implode(",", $keys) . ") 
          VALUES (" . implode(",", $values) . ");";

echo $query;

