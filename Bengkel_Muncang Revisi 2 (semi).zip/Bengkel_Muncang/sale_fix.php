<HTML>

<?php
require_once 'config.php';
session_start();
$number = count($_SESSION['id']);
$id = $_SESSION['id'];
$jumlah = $_SESSION['jumlah'];
$harga = $_SESSION['harga'];

//Queries
$query1 = "UPDATE spareparts SET stock = stock - $jumlah WHERE id_tipe =$id";
$query2 = "SELECT stock FROM spareparts WHERE id_tipe =$id ";
//$query3 = "INSERT INTO riwayat_jual (id_tipe,jumlah) VALUES ($id,$jumlah)";
$query4 = "INSERT INTO riwayat_jual (id_tipe,jumlah) VALUES ";
$prep1 = pg_prepare($link,"reduce",$query1);
$prep2 = pg_prepare($link,"check",$query2);
//$prep3 = pg_prepare($link,"historize",$query3);

pg_query("BEGIN") or die("Could not start transaction\n");

if($number > 1)
{
	for($i=0; $i<$number-1; $i++)
	{
		if(trim($_POST["iid"][$i] != ''))
		{
			$query4 .= "($id[$i]),";
		}
	
	}
	$query4 .= "($id[$i])";
    $prep1 = pg_execute($link,"reduce",array());
    $prep2 = pg_execute($link,"check",array());
    //$prep3 = pg_execute($link,"historize",array());
    $query4 = pg_query($query4);
    $data = pg_fetch_assoc($prep2);
}
else 
{
    echo ("<script>
    alert('Tidak ada Input. Harap Cek kembali input!');
    window.location.href='sale.php';
    </script>");
}


if ($data['stock'] < 0 )
    {
    pg_query("ROLLBACK") or die("ROLLBACK failed\n");
    echo ("<script>
    alert('Transaksi Gagal, karena STOCK TIDAK ADA/HABIS. Harap cek transaksi kembali!');
    window.location.href='sale.php';
    </script>");
    }
else
    {
    pg_query("COMMIT") or die("Transaction commit failed\n");
    echo ("<script>
    alert('Transaksi BERHASIL.');
    window.location.href='sale.php';
    </script>");
    }

?>
</HTML>
