<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>HomePage Bengkel</title>
    <link rel="stylesheet" href="theme3.css" />  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    <br><br>
</head>
<body>

<form class = "container">
    <a class="page-header">INI HOMEPAGE NYA, KLIK ADD DULU GAN</a><br><br>

<form class = "button">

    <a href="insert_own.php" class="button">Add New Item</a><br><br>
    <a href="view.php" class="btn">View Test</a> 
          
</body>
</html>