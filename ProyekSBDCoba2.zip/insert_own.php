<?php
require_once "config.php";

$id = $nama = $merk = $stock = $harga = '';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    try 
    {
        $id = (int)$_POST['i_serial'];
        $nama = $_POST['iNamaBarang'];
        $merk = $_POST["iMerkBarang"];
        $harga = (float)$_POST["iHarga"];
        $stock = (int)$_POST["iStock"];

        $insert_into = "INSERT INTO riwayat_servis(serial_id,nama_barang,merk_barang,harga,stock) VALUES ('$id','$nama','$merk','$harga','$stock')";

        pg_query($link, $insert_into);
        echo 'SUKSES!';
    }
    catch(Exception $e)
    {
        echo $e;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link rel="stylesheet" href="theme3.css" />  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>

<body>
<form action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" METHOD="POST">  
  
     <div class="container">
        <div class="form-group">
            <br>
            <label for="i_serial">ID Serial Barang</label>
            <input name = "i_serial" type="text">
            
            <br><br>

            <label for="iNamaBarang">Nama Spare Parts</label>
            <input name = "iNamaBarang" type="text">
            
            <br><br>

            <label for="iMerkBarang">Merk Barang</label>
            <input name = "iMerkBarang" type="text">
            
            <br><br>

            <label for="iHarga">Harga Satuan</label>
            <input name = "iHarga" type="text">
            
            <br><br>

            <label for="iStock">Sisa Stock</label>
            <input name = "iStock" type="text">
        </div>
    </div>

<input type="submit" class="btn btn-primary" value="Submit">
<a type="submit" href="index.php" class="btn" value="Finish">Finish</a>
</body>
</html>
